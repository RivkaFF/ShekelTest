﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShekelGroupTest.Model
{
    public class Group
    {
        public int GroupCode { get; set; }
        public string GroupName { get; set; }

    }
}
