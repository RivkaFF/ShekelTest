﻿namespace ShekelGroupTest.Model
{
    public class ShekelContext: DbContext
    {
    }
}
