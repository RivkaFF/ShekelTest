﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShekelGroupTest.Model
{
    public class Factory
    {
        public int GroupCode { get; set; }
        public int FactoryCode { get; set; }

        public string FactoryName { get; set; }

    }
}
